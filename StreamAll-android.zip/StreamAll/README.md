# StreamAll 📺

Application Android (WebView) qui emballe l'app web **StreamAll** : films, séries, jeunesse et animés, via les API gratuites **TMDB**, **AniList**, **Jikan** et **MyMemory**.

L'app web complète est embarquée dans l'APK (`app/src/main/assets/streamall.html`) : elle fonctionne sans serveur, seules les API publiques sont appelées via Internet.

## 🆕 Nouveautés

**v2.0 — nouvel onglet « Ciné » 🎴 (longs-métrages d'animation japonaise)**
- 5ᵉ onglet dédié aux **films d'animés** (Ghibli, One Piece, *Your Name*, *Demon Slayer*…), alimenté par AniList + Jikan filtrés sur le **format film** (`format:MOVIE` / `type=movie`).
- Réutilise toute l'infra animés : file anti-429, gros catalogue, recherche, casting, similaires, fournisseurs de streaming, lecteur de bande-annonce.
- Genres, tri et traduction des synopsis identiques à l'onglet Animés ; cache séparé par onglet.

**v1.9 — plafond d'animés relevé**
- Cible portée à **~12 000 titres**, **pagination plus profonde** par tri (80 pages) et complétion **Jikan élargie**. Pour ajuster, modifier `TARGET` dans la fonction `loadMassiveAnime` (fichier `streamall.html`).

**v1.8 — catalogue d'animés enrichi**
- **Beaucoup plus de titres** dans l'onglet Animés : plafond relevé (jusqu'à ~8 000), **6 tris AniList** différents pour faire remonter des titres variés (populaires, notés, tendances, favoris, récents, catalogue), et **fusion systématique AniList + Jikan** (deux catalogues complémentaires) en mode Auto.
- **Chargement plus fiable** : réessai automatique en cas de saturation AniList (429, avec respect du délai demandé), pour que les gros chargements ne s'arrêtent plus en silence.
- Synopsis stockés légèrement raccourcis et cache d'animés optimisé pour garder des retours instantanés malgré le plus grand volume.

**v1.7 — chargement des animés plus fiable**
- **File anti-429 pour Jikan** : toutes les requêtes Jikan passent par une file qui respecte ses limites (~3/s, 60/min) et **réessaie automatiquement** en cas de saturation (erreur 429, avec respect du délai demandé). Fini les pages d'animés qui sautaient silencieusement quand l'API était sollicitée.

**v1.6 — casting & titres similaires**
- **🎭 Casting** dans la fiche : acteurs (films/séries, via TMDB) ou personnages + voix japonaises (animés, via AniList), en défilement horizontal.
- **🎬 « Vous aimerez aussi »** : recommandations de titres ; **touchez-en un pour ouvrir sa fiche** directement (navigation enchaînée). TMDB pour films/séries, AniList pour les animés.

**v1.5 — bande-annonce intégrée**
- **▶️ Lecteur de bande-annonce dans la fiche** : la vraie bande-annonce se lit directement dans l'appli (lecteur YouTube), au lieu d'ouvrir le navigateur. Source : TMDB pour films/séries, AniList/Jikan pour les animés. Chargée seulement au clic (perfs) et coupée à la fermeture. La recherche YouTube reste en repli si aucune bande-annonce n'est trouvée.

**v1.4 — sauvegarde des favoris**
- **💾 Sauvegarder / Restaurer** (bouton dans la vue **Favoris**) : exporte vos favoris **et** votre clé TMDB en un texte à copier-coller (notes, e-mail…), et réimporte une sauvegarde. Les favoris importés s'ajoutent sans doublons ; la clé n'est restaurée que si vous n'en avez pas. Idéal pour ne rien perdre en cas de réinstallation.

**v1.3 — où regarder**
- **▶️ Section « Où regarder »** dans la fiche détail : recherche **Google** + **DuckDuckGo**, agrégateur légal **JustWatch** (FR), et liens directs vers les plateformes selon le type — **Crunchyroll · ADN · Netflix** pour les animés, **Netflix · Disney+ · Prime Video** pour films/séries/jeunesse. Le bouton bande-annonce YouTube est conservé.
- Tous les liens sont **centralisés dans la fonction `buildProviders`** du fichier `streamall.html` — faciles à modifier si une plateforme change l'URL de sa recherche.

**v1.2 — confort Android**
- **🚀 Écran de démarrage** (SplashScreen API) maintenu à l'écran jusqu'à ce que l'app soit prête.
- **🔄 Tirer pour rafraîchir** : un glissement vers le bas en haut de liste vide le cache et recharge des données fraîches.
- **📡 Bandeau hors-ligne** : prévient quand il n'y a pas de réseau (les listes restent consultables, mais aucune nouvelle donnée ne peut être chargée).
- **🔙 Bouton Retour intelligent** : ferme la fiche détail si elle est ouverte, sinon revient en arrière, sinon « Appuyez à nouveau pour quitter ».

**v1.1 — favoris & cache**
- **⭐ Favoris** : un cœur sur chaque affiche et dans la fiche détail. Bouton **Favoris** dans l'en-tête pour retrouver tous vos titres (films, séries, animés mélangés), avec tri et recherche. Mémorisés sur l'appareil (`localStorage`).
- **⚡ Cache des résultats** : les listes chargées (TMDB et surtout les milliers d'animés) sont mises en cache pour la session (`sessionStorage`, 6 h). Naviguer entre les onglets devient instantané et ça épargne les quotas des API.

---

## 📦 Obtenir l'APK sans rien installer (GitHub Actions)

C'est la méthode la plus simple — **aucun SDK Android à installer sur votre machine**.

1. Créez un dépôt GitHub et **poussez ce dossier** dessus :
   ```bash
   git init
   git add .
   git commit -m "StreamAll APK"
   git branch -M main
   git remote add origin https://github.com/VOTRE_PSEUDO/StreamAll.git
   git push -u origin main
   ```
2. Sur GitHub, ouvrez l'onglet **Actions**. Le workflow *Build StreamAll APK* se lance tout seul (sinon cliquez sur **Run workflow**).
3. Quand il est terminé (✅), cliquez dessus puis téléchargez l'artefact **`StreamAll-debug`** en bas de page.
4. Décompressez le `.zip` : vous obtenez **`app-debug.apk`**.

> L'APK `debug` est **directement installable** sur un téléphone (signé avec la clé de debug). L'APK `release` fourni est **non signé** (à signer vous-même pour une publication).

---

## 📲 Installer l'APK sur un téléphone Android

1. Transférez `app-debug.apk` sur le téléphone (câble, Drive, e-mail…).
2. Ouvrez-le. Android demandera d'autoriser **« Installer des applis inconnues »** pour votre gestionnaire de fichiers / navigateur → acceptez.
3. Installez, puis lancez **StreamAll**.

---

## 🔑 Clé API TMDB

Films / Séries / Jeunesse utilisent **TMDB**. Au premier lancement :
- collez votre clé gratuite (compte sur https://www.themoviedb.org/settings/api), **ou**
- appuyez sur **🎭 Démo** pour tester immédiatement.

La clé est mémorisée localement sur l'appareil (`localStorage`). L'onglet **Animés** ne nécessite aucune clé.

---

## 🛠️ Compiler en local (Android Studio)

1. **Android Studio** (Hedgehog ou plus récent), puis *File → Open* et sélectionnez ce dossier.
2. Android Studio télécharge automatiquement le wrapper Gradle et les dépendances. Patientez à la fin de la synchronisation.
3. *Build → Build App Bundle(s) / APK(s) → Build APK(s)*, ou en ligne de commande :
   ```bash
   # Si le wrapper n'est pas encore généré :
   gradle wrapper --gradle-version 8.7
   # Puis :
   ./gradlew assembleDebug      # -> app/build/outputs/apk/debug/app-debug.apk
   ```

**Prérequis** : JDK 17, Android SDK avec `platforms;android-34` et `build-tools;34.0.0`.

---

## 🗂️ Structure du projet

```
StreamAll/
├─ .github/workflows/build-apk.yml   # CI : compile l'APK automatiquement
├─ app/
│  ├─ build.gradle                   # config du module app (SDK, deps)
│  ├─ proguard-rules.pro
│  └─ src/main/
│     ├─ AndroidManifest.xml         # permissions, activité, thème
│     ├─ assets/streamall.html       # ← l'application web embarquée
│     ├─ java/com/streamall/app/
│     │  └─ MainActivity.java         # WebView + WebViewAssetLoader
│     └─ res/
│        ├─ drawable/                 # icône adaptative (vecteur)
│        ├─ layout/activity_main.xml  # WebView plein écran
│        ├─ mipmap-*/                 # icônes de lancement (toutes densités)
│        ├─ values/                   # couleurs, thème, nom de l'app
│        └─ xml/                      # config de sécurité réseau
├─ build.gradle                       # build racine
├─ settings.gradle
├─ gradle.properties
├─ gradle/wrapper/…                   # config du wrapper Gradle
├─ gradlew / gradlew.bat              # scripts wrapper
├─ .gitignore
└─ README.md
```

---

## ⚙️ Choix techniques (pour une app fluide)

- **`WebViewAssetLoader`** : le HTML local est servi sur une origine HTTPS virtuelle (`https://appassets.androidplatform.net/`). Cela rend `localStorage` fiable et autorise les requêtes `fetch()` (CORS standard) vers TMDB / AniList / Jikan / MyMemory.
- **Accélération matérielle** activée, défilement sans effet de débordement, barres de défilement masquées.
- **`configChanges`** : la rotation ne recrée pas l'activité (l'état de la WebView est conservé).
- **Java + une seule dépendance** (`androidx.webkit`) : build léger et rapide.
- Les liens externes (recherche streaming, bande-annonce YouTube, page TMDB) s'ouvrent dans le **navigateur**.

---

## ✍️ Personnalisation rapide

| Quoi | Où |
|------|----|
| Nom de l'app | `app/src/main/res/values/strings.xml` |
| Couleurs / barre de statut | `app/src/main/res/values/colors.xml` |
| Icône | `app/src/main/res/drawable/ic_launcher_*` et `mipmap-*/` |
| Identifiant du package | `applicationId` dans `app/build.gradle` + `namespace` |
| Mettre à jour l'app web | remplacez `app/src/main/assets/streamall.html` |

---

## ⚠️ Note

StreamAll est un **agrégateur de découverte** (métadonnées + liens de recherche). Il n'héberge ni ne diffuse aucun contenu. Respectez les conditions d'utilisation des API et la législation de votre pays.
