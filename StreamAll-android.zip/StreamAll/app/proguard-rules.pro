# StreamAll — règles ProGuard / R8.
# minifyEnabled est à false par défaut, ces règles servent de filet de sécurité
# si vous activez l'obfuscation plus tard.

# Conserver les éléments WebView (utile si vous ajoutez un @JavascriptInterface)
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class androidx.webkit.** { *; }
