package com.streamall.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.splashscreen.SplashScreen;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.webkit.WebViewAssetLoader;

/**
 * StreamAll — conteneur natif Android.
 *
 * L'app web (assets/streamall.html) est servie via WebViewAssetLoader sur le domaine
 * virtuel https://appassets.androidplatform.net/ (origine HTTPS réelle -> localStorage
 * fiable + fetch() CORS standard vers TMDB / AniList / Jikan / MyMemory).
 *
 * Ajouts v1.2 :
 *   - Écran de démarrage (SplashScreen API) maintenu jusqu'au chargement de la page.
 *   - Tirer pour rafraîchir (SwipeRefreshLayout) : vide le cache de session puis recharge.
 *   - Pont JS -> natif : la fiche détail (modale) désactive le pull-to-refresh et le
 *     bouton Retour la ferme au lieu de quitter l'app.
 *   - Double appui sur Retour pour quitter.
 */
public class MainActivity extends Activity {

    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String APP_URL  = "https://" + APP_HOST + "/assets/streamall.html";

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private boolean contentReady = false;
    private volatile boolean modalOpen = false;
    private long lastBackPress = 0L;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Doit être appelé avant super.onCreate()
        SplashScreen splash = SplashScreen.installSplashScreen(this);
        super.onCreate(savedInstanceState);

        // Le splash reste visible tant que la page n'est pas chargée…
        splash.setKeepOnScreenCondition(() -> !contentReady);
        // …mais jamais plus de 3,5 s (sécurité).
        new Handler(Looper.getMainLooper()).postDelayed(() -> contentReady = true, 3500);

        setContentView(R.layout.activity_main);

        swipeRefresh = findViewById(R.id.swipeRefresh);
        webView      = findViewById(R.id.webview);

        swipeRefresh.setColorSchemeColors(0xFF7C4DFF, 0xFF4FC3F7);
        swipeRefresh.setOnRefreshListener(this::refreshContent);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(APP_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Laisser charger les sous-cadres (iframe de bande-annonce YouTube, etc.)
                if (!request.isForMainFrame()) return false;
                Uri url = request.getUrl();
                if (APP_HOST.equals(url.getHost())) return false;   // contenu interne -> WebView
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, url)); // liens externes -> navigateur
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                contentReady = true;
                if (swipeRefresh != null) swipeRefresh.setRefreshing(false);
            }
        });

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                 // localStorage (favoris, clé TMDB)
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(false);           // target="_blank" géré dans le frame principal
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(APP_URL);
        }
    }

    /** Rafraîchissement : vide le cache de session puis recharge pour des données fraîches. */
    private void refreshContent() {
        if (webView == null) { if (swipeRefresh != null) swipeRefresh.setRefreshing(false); return; }
        webView.evaluateJavascript(
            "try{Object.keys(sessionStorage).filter(function(k){return k.indexOf('cache:')===0;})"
          + ".forEach(function(k){sessionStorage.removeItem(k);});}catch(e){}",
            value -> webView.reload());
    }

    /** Pont JS -> natif : l'app web signale l'ouverture/fermeture de la fiche détail. */
    private class Bridge {
        @JavascriptInterface
        public void onModalOpen(final boolean open) {
            runOnUiThread(() -> {
                modalOpen = open;
                if (swipeRefresh != null) swipeRefresh.setEnabled(!open);
            });
        }
    }

    @Override
    public void onBackPressed() {
        // 1) Fiche détail ouverte -> la fermer
        if (modalOpen) {
            webView.evaluateJavascript("if(typeof closeModal==='function')closeModal();", null);
            return;
        }
        // 2) Historique WebView -> revenir en arrière
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        // 3) Double appui pour quitter
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 2000) {
            super.onBackPressed();
        } else {
            lastBackPress = now;
            Toast.makeText(this, R.string.press_back_again, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }
}
